@extends('layouts.main2')

@section('content')
    <div class="container mx-auto p-4 my-6 bg-white dark:bg-gray-800 text-black dark:text-gray-100">
        <h1 class="text-2xl font-bold mb-4">Daftar Chatbot</h1>
        <div class="flex justify-between mb-4">
            <a href="{{ route('chatbot.create') }}"
                class="px-4 py-2 text-white bg-green-600 rounded-md hover:bg-green-700">Create Data</a>
            <a href="{{ route('chatbot.ask') }}" class="px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-700">Chat
                with Chatbot</a>
        </div>


        @if (session('success'))
            <div class="mb-4 p-2 bg-green-100 text-green-800 border border-green-200 rounded">
                {{ session('success') }}
            </div>
        @endif

        <table class="table-auto w-full border-collapse border border-gray-800 dark:border-gray-600 my-6 bg-white dark:bg-gray-800 text-black dark:text-gray-100">
            <thead>
                <tr class="bg-gray-100">
                    <th class="border border-gray-800 dark:border-gray-600 px-4 py-2">#</th>
                    <th class="border border-gray-800 dark:border-gray-600 px-4 py-2">Pertanyaan</th>
                    <th class="border border-gray-800 dark:border-gray-600 px-4 py-2">Jawaban</th>
                    <th class="border border-gray-800 dark:border-gray-600 px-4 py-2">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($chatbot as $chatbot)
                    <tr>
                        <td class="border border-gray-800 dark:border-gray-600 px-4 py-2">{{ $loop->iteration }}</td>
                        <td class="border border-gray-800 dark:border-gray-600 px-4 py-2">{{ $chatbot->pertanyaan }}</td>
                        <td class="border border-gray-800 dark:border-gray-600 px-4 py-2">{{ $chatbot->jawaban }}</td>
                        <td class="border border-gray-800 dark:border-gray-600 px-4 py-2">
                            <a href="{{ route('chatbot.edit', $chatbot->id) }}"
                                class="text-blue-500 hover:underline">Edit</a>
                            <form action="{{ route('chatbot.destroy', $chatbot->id) }}" method="POST"
                                style="display:inline-block;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-500 hover:underline"
                                    onclick="return confirm('Hapus data ini?')">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" class="border border-gray-800 dark:border-gray-600 px-4 py-2 text-center">Tidak ada data.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
@endsection
