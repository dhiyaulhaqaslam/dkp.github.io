<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ $title }}</title>
    <link href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <style>
        .chat-container {
            width: 100%;
            height: 100vh;
            background-color: #fff;
            display: flex;
            flex-direction: column;
            box-shadow: 0px -5px 10px rgba(0, 0, 0, 0.2);
            z-index: 9999;
        }

        .chat-box {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .chat-content {
            flex-grow: 1;
            overflow-y: auto;
            padding: 10px;
            margin-bottom: 10px;
        }

        .chat-input {
            padding: 12px;
            border-radius: 20px;
            border: 1px solid #ddd;
            font-size: 16px;
            margin: 10px;
        }
    </style>
</head>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-100">
    <!-- Navbar untuk Tombol Kembali -->
    <nav class="bg-gray-200 dark:bg-gray-800 p-4">
        <div class="container mx-auto">
            <a href="{{ $backUrl }}"
                class="inline-flex items-center gap-1 px-3 py-2 text-indigo-600 dark:text-white border border-indigo-600 dark:border-white rounded hover:bg-indigo-600 hover:text-white dark:hover:bg-white dark:hover:text-black focus:outline-none focus:ring active:bg-indigo-500">
                <svg class="w-4 h-4 rotate-180" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
                <span class="text-sm font-medium">Kembali</span>
                <div class="flex justify-end mb-4">
                    <a href="{{ route('chatbot.create') }}"
                        class="px-4 py-2 text-white bg-green-600 rounded-md hover:bg-green-700">Tambah Data</a>
                </div>
            </a>
        </div>
    </nav>

    <!-- Chatbot Container -->
    <div class="container mx-auto mt-6 px-4 sm:px-6 lg:px-8">
        <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
            <!-- Chatbox -->
            <div id="chatBox"
                class="p-4 h-[400px] sm:h-[500px] overflow-y-auto border-b border-gray-300 dark:border-gray-700">
                <div id="chatContent" class="space-y-4"></div>
            </div>
            <!-- Input -->
            <div class="p-4 bg-gray-100 dark:bg-gray-900">
                <input id="chatInput" type="text" placeholder="Tanyakan sesuatu..."
                    class="w-full px-4 py-2 text-sm text-gray-800 dark:text-gray-200 bg-gray-200 dark:bg-gray-700 rounded-lg border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-500">
            </div>
        </div>
    </div>

    <!-- Script -->
    <script>
        const chatContent = document.getElementById('chatContent');
        const chatInput = document.getElementById('chatInput');

        const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        chatInput.addEventListener('keypress', async function(e) {
            if (e.key === 'Enter' && chatInput.value.trim() !== '') {
                const pertanyaan = chatInput.value.trim();
                chatInput.value = '';
                appendMessage('Anda', pertanyaan, 'text-indigo-500');

                try {
                    const response = await fetch('/chatbot/ask', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': token
                        },
                        body: JSON.stringify({
                            pertanyaan
                        })
                    });

                    if (!response.ok) throw new Error('Error ' + response.status);

                    const {
                        jawaban
                    } = await response.json();
                    appendMessage('Bot', jawaban, 'text-gray-800');
                } catch (error) {
                    console.error('Error:', error);
                    appendMessage('Bot', 'Maaf, terjadi kesalahan. Coba lagi nanti.', 'text-red-500');
                }
            }
        });

        function appendMessage(sender, message, textColor) {
            const msgHTML = `
                <div class="${textColor}">
                    <strong>${sender}:</strong>
                    <div class="p-2 mt-1 rounded-md bg-gray-100 dark:bg-gray-700 text-sm">
                        ${escapeHTML(message)}
                    </div>
                </div>
            `;
            chatContent.insertAdjacentHTML('beforeend', msgHTML);
            chatContent.scrollTop = chatContent.scrollHeight;
        }

        function escapeHTML(str) {
            return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(
                /'/g, "&#039;");
        }
    </script>
</body>


</html>
