<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __($title) }}
        </h2>
    </x-slot>
    <div class="h-full">
        <div
            class="w-full max-w-7xl mx-auto flex justify-center items-center content-center bg-white dark:bg-gray-900 text-gray-800 dark:text-white">
            <div class="shadow-md rounded-lg">
                @auth
                    <p class="mb-10">
                        <a class="px-6 py-3 bg-indigo-500 text-white font-light rounded-md hover:bg-indigo-600 transition duration-300"
                            href="{{ route('informasi.create') }}">Create</a>
                    </p>
                @endauth

                @if (session('success'))
                    <div class="mb-4 p-4 bg-green-100 text-green-700 rounded">
                        {{ session('success') }}
                    </div>
                @endif

                <table class="table-auto w-full border">
                    <thead>
                        <tr>
                            <th class="border px-4 py-2">No</th>
                            <th class="border px-4 py-2">Judul</th>
                            <th class="border px-4 py-2">Deskripsi</th>
                            <th class="border px-4 py-2">Gambar</th>
                            <th class="border px-4 py-2">Video</th>
                            <th class="border px-4 py-2">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($informasi as $info)
                            <tr>
                                <td class="border px-4 py-2">{{ $loop->iteration }}</td>
                                <td class="border px-4 py-2">{{ $info->judul }}</td>
                                <td class="border px-4 py-2">{{ $info->deskripsi }}</td>
                                <td class="border px-4 py-2">
                                    @if ($info->gambar)
                                        <img src="{{ asset('storage/' . $info->gambar) }}" alt="Gambar"
                                            class="h-20 w-20">
                                    @else
                                        Tidak ada gambar
                                    @endif
                                </td>
                                <td class="border px-4 py-2">
                                    @if ($info->video_link)
                                        @php
                                            preg_match(
                                                '/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?\/?|watch\?v=))|youtu\.be\/)([^\&\?\/]+)/',
                                                $info->video_link,
                                                $matches,
                                            );
                                            $videoId = $matches[1] ?? null;
                                        @endphp

                                        @if ($videoId)
                                            <a href="{{ $info->video_link }}" target="_blank">
                                                <img src="https://img.youtube.com/vi/{{ $videoId }}/hqdefault.jpg"
                                                    class="rounded" alt="Thumbnail Video">
                                            </a>
                                        @else
                                            <img src="https://images.unsplash.com/photo-1731690415686-e68f78e2b5bd?q=80&w=2670&auto=format&fit=crop"
                                                class="rounded" alt="Gambar Default">
                                        @endif
                                    @else
                                        <img src="https://images.unsplash.com/photo-1731690415686-e68f78e2b5bd?q=80&w=2670&auto=format&fit=crop"
                                            class="rounded" alt="Gambar Default">
                                    @endif
                                </td>
                                <td class="px-4 py-2 text-center">
                                    <a href="{{ route('informasi.edit', $info->id) }}"
                                        class="bg-indigo-500 hover:bg-indigo-600 rounded-md px-3 py-1 text-white">
                                        Edit
                                    </a>
                                    <form action="{{ route('informasi.destroy', $info->id) }}" method="POST"
                                        onsubmit="return confirm('Apakah Anda yakin ingin menghapus informasi ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit"
                                            class="bg-red-500 hover:bg-red-600 rounded-md px-3 py-1 text-white">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-app-layout>
