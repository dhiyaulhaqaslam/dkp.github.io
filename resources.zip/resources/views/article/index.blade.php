@extends('layouts.main2')

@section('content')
    <!-- MAIN -->
    <div class="justify-items-center py-4 bg-white dark:bg-gray-900 text-gray-800 dark:text-white">
        <h1 class="mb-4 py-4 text-4xl font-semibold">{{ $title }}</h1>
        @auth
            <div class="text-center my-5">
                <a href="{{ route('article.create') }}" class="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                    Create Proyek
                </a>
            </div>
        @endauth
        <div class="w-full lg:w-1/2 grid grid-cols-1 gap-4 my-10">
            @if (session()->has('success'))
                <div id="alert-message" class="alert alert-success">
                    {{ session('success') }}
                </div>
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        const alertMessage = document.getElementById('alert-message');
                        if (alertMessage) {
                            setTimeout(() => {
                                alertMessage.style.transition = "opacity 0.5s ease"; // Animasi transisi
                                alertMessage.style.opacity = 0; // Mengurangi opacity hingga 0
                                setTimeout(() => alertMessage.remove(),
                                    500); // Menghapus elemen setelah animasi selesai
                            }, 3000); // Durasi tampilan sebelum mulai menghilang (3 detik)
                        }
                    });
                </script>
            @endif
            @foreach ($articles as $article)
                <article
                    class="overflow-hidden rounded-lg border border-gray-100 dark:border-gray-600 shadow-md hover:shadow-lg transition duration-300 max-w-xl mx-auto min-w-md">
                    <a href="{{ route('article', $article->id) }}">
                        <img rour alt="" src="{{ asset('storage/' . $article->image) }}"
                            class="h-56 w-full object-cover transition duration-300 transform hover:scale-105" />
                    </a>
                    <div class="p-4 sm:p-6">
                        <p class="text-sm">Tanggal: {{ $article->tanggal }}</p>
                        <a href="#">
                            <h3 class="text-lg font-medium">
                                {{ $article->title }}
                            </h3>
                        </a>

                        <p class="mt-2 line-clamp-3 text-sm">
                            {{ $article->excerpt }}
                        </p>

                        <a href="{{ route('article', $article->id) }}"
                            class="group mt-4 inline-flex items-center gap-1 text-sm font-medium text-blue-600 hover:underline">
                            Find out more
                            <span aria-hidden="true" class="block transition-all group-hover:ms-0.5 rtl:rotate-180">
                                &rarr;
                            </span>
                        </a>
                        @auth
                            <div class="flex gap-2 mt-4">
                                <!-- Tombol Edit -->
                                <a href="{{ route('article.edit', $article->id) }}"
                                    class="px-4 py-2 text-sm font-medium text-white bg-yellow-500 rounded-lg shadow-md hover:bg-yellow-600 transition duration-300">
                                    <i class="fas fa-edit"></i> Edit
                                </a>

                                <!-- Tombol Delete -->
                                <form action="{{ route('article.destroy', $article) }}" method="POST" class="inline-block">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit"
                                        class="px-4 py-2 text-sm font-medium text-white bg-red-500 rounded-lg shadow-md hover:bg-red-600 transition duration-300"
                                        onclick="return confirm('Yakin ingin menghapus?')">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </form>
                            </div>
                        @endauth
                    </div>
                </article>
            @endforeach
        </div>
    </div>
@endsection
