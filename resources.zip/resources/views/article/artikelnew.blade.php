@extends('layouts.main2')

@section('content')
    <div class="py-8 mx-auto ">
        <div class="max-w-3xl xl:max-w-4xl mx-auto bg-gray-50 dark:bg-gray-800 text-gray-800 dark:text-white p-10 rounded-md">
            <!-- Judul Artikel -->
            <p class="text-sm mb-4">Diterbitkan pada: {{ $article->tanggal }}</p>
            <h1 class="text-3xl sm:text-4xl font-bold  mb-6">{{ $article->title }}</h1>

            <!-- Gambar Artikel -->
            @if ($article->image)
                <div class="mb-6">
                    <img src="{{ asset('storage/' . $article->image) }}" alt="Image"
                        class="rounded-lg w-full h-auto shadow-md">
                </div>
            @endif

            <!-- Konten Artikel -->
            <div class="text-lg leading-relaxed text-justify space-y-6">
                @php
                    // Pecah konten berdasarkan titik untuk memisahkan paragraf
                    $sentences = explode('.', $article->content);
                    $paragraphs = [];
                    $temp = '';

                    foreach ($sentences as $sentence) {
                        $temp .= trim($sentence) . '. ';
                        // Setiap 2-3 kalimat dijadikan satu paragraf
                        if (str_word_count($temp) > 30) {
                            $paragraphs[] = $temp;
                            $temp = '';
                        }
                    }
                    // Createkan sisa kalimat terakhir sebagai paragraf
                    if (!empty($temp)) {
                        $paragraphs[] = $temp;
                    }
                @endphp

                <!-- Render paragraf -->
                @foreach ($paragraphs as $paragraph)
                    <p>{{ trim($paragraph) }}</p>
                @endforeach
            </div>
        </div>

        <!-- Tombol Create Proyek (jika user terautentikasi) -->
        @auth
            <div class="text-center mt-8">
                <a href="{{ route('article.create') }}"
                    class="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                    Create Proyek
                </a>
            </div>
        @endauth
    </div>
@endsection
