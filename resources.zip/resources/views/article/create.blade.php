@extends('layouts.main2')

@section('content')
    <div class="w-full sm:w-1/2 mx-auto py-4 bg-white dark:bg-gray-900 text-gray-800 dark:text-white">
        <h1 class="mb-4 py-4 text-4xl text-center font-semibold">Create Artikel Baru</h1>

        <form action="{{ route('article.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="mb-4">
                <label for="title" class="block text-sm font-medium">Judul Artikel</label>
                <input type="text"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white dark:bg-gray-900 text-gray-800 dark:text-white"
                    id="title" name="title" required>
            </div>

            <div class="mb-4">
                <label for="tanggal" class="block text-sm font-medium">Tanggal</label>
                <input type="date"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white dark:bg-gray-900 text-gray-800 dark:text-white"
                    id="tanggal" name="tanggal" required>
            </div>

            <div class="mb-4">
                <label for="image" class="block text-sm font-medium">Unggah Gambar</label>
                <input type="file"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white dark:bg-gray-900 text-gray-800 dark:text-white"
                    id="image" name="image" accept="image/*">
            </div>

            <div class="mb-4">
                <label for="excerpt" class="block text-sm font-medium">Excerpt</label>
                <input type="text"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white dark:bg-gray-900 text-gray-800 dark:text-white"
                    id="excerpt" name="excerpt" required>
            </div>

            <div class="mb-4">
                <label for="content" class="block text-sm font-medium">Konten Artikel</label>
                <textarea
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white dark:bg-gray-900 text-gray-800 dark:text-white"
                    id="content" name="content" rows="5" required></textarea>
            </div>

            <button type="submit"
                class="py-2 px-4 bg-blue-500 font-semibold rounded-md shadow-md hover:bg-blue-600 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
                Simpan
            </button>
        </form>
    </div>
@endsection
