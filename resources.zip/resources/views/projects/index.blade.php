@extends('layouts.main2')

@section('content')
    <div class="container mx-auto px-4 py-6 bg-white dark:bg-gray-900 text-gray-800 dark:text-white">
        <h1 class="text-4xl font-bold text-center mb-6">{{ $title }}</h1>
        @auth
            <a href="{{ route('projects.create') }}"
               class="inline-block bg-indigo-500 text-white px-4 py-2 rounded-md shadow hover:bg-indigo-600 transition duration-200">
                Create Proyek
            </a>
        @endauth

        <div class="overflow-x-auto mt-6">
            <table class="table-auto w-full border-collapse border border-gray-300 dark:border-gray-600 text-center dark:bg-gray-800">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="border border-gray-300 dark:border-gray-600 px-4 py-2">#</th>
                        <th class="border border-gray-300 dark:border-gray-600 px-4 py-2">Nama</th>
                        <th class="border border-gray-300 dark:border-gray-600 px-4 py-2">Status</th>
                        <th class="border border-gray-300 dark:border-gray-600 px-4 py-2">Tanggal</th>
                        <th class="border border-gray-300 dark:border-gray-600 px-4 py-2">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($projects as $project)
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                            <td class="border border-gray-300 dark:border-gray-600 px-4 py-2">{{ $loop->iteration }}</td>
                            <td class="border border-gray-300 dark:border-gray-600 px-4 py-2">{{ $project->name }}</td>
                            <td class="border border-gray-300 dark:border-gray-600 px-4 py-2">{{ ucfirst($project->status) }}</td>
                            <td class="border border-gray-300 dark:border-gray-600 px-4 py-2">{{ $project->tanggal ? $project->tanggal->format('d M Y') : '-' }}</td>
                            <td class="border border-gray-300 dark:border-gray-600 px-4 py-2">
                                <a href="{{ route('projects.show', $project) }}"
                                   class="inline-block bg-blue-400 text-white px-3 py-1 rounded-md shadow hover:bg-blue-500 transition duration-200">
                                    Detail
                                </a>
                                @auth
                                    <a href="{{ route('projects.edit', $project) }}"
                                       class="inline-block bg-yellow-400 text-white px-3 py-1 rounded-md shadow hover:bg-yellow-500 transition duration-200">
                                        Edit
                                    </a>
                                    <form action="{{ route('projects.destroy', $project) }}" method="POST" class="inline-block">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit"
                                                class="inline-block bg-red-500 text-white px-3 py-1 rounded-md shadow hover:bg-red-600 transition duration-200"
                                                onclick="return confirm('Yakin ingin menghapus?')">
                                            Delete
                                        </button>
                                    </form>
                                @endauth
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <div class="mt-6">
            {{ $projects->links() }}
        </div>
    </div>
@endsection
