@extends('layouts.main2')

@section('content')
    <div class="container mx-auto py-6 bg-white dark:bg-gray-900 text-gray-800 dark:text-white">
        <h1 class="mb-6 text-4xl font-semi-bold text-center">{{ $title }}</h1>

        <form action="{{ route('projects.update', $project->id) }}" method="POST" class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
            @csrf
            @method('PUT')

            <!-- Nama Proyek -->
            <div class="mb-4">
                <label for="name" class="block font-semi-bold mb-2">Nama Proyek</label>
                <input type="text" name="name" id="name"
                    class="dark:bg-gray-800 w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 @error('name') border-red-500 @enderror"
                    value="{{ old('name', $project->name) }}" required>
                @error('name')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Tanggal -->
            <div class="mb-4">
                <label for="tanggal" class="block font-semi-bold mb-2">Tanggal</label>
                <input type="date" name="tanggal" id="tanggal"
                    class="dark:bg-gray-800 w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 @error('tanggal') border-red-500 @enderror"
                    value="{{ old('tanggal', $project->tanggal) }}">
                @error('tanggal')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Deskripsi -->
            <div class="mb-4">
                <label for="description" class="block font-semi-bold mb-2">Deskripsi</label>
                <textarea name="description" id="description" rows="4"
                    class="dark:bg-gray-800 w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 @error('description') border-red-500 @enderror">{{ old('description', $project->description) }}</textarea>
                @error('description')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Status -->
            <div class="mb-4">
                <label for="status" class="block font-semi-bold mb-2">Status</label>
                <select name="status" id="status"
                    class="dark:bg-gray-800 w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 @error('status') border-red-500 @enderror">
                    <option value="rencana" {{ old('status', $project->status) == 'rencana' ? 'selected' : '' }}>Rencana
                    </option>
                    <option value="progres" {{ old('status', $project->status) == 'progres' ? 'selected' : '' }}>Progres
                    </option>
                    <option value="arsip" {{ old('status', $project->status) == 'arsip' ? 'selected' : '' }}>Arsip
                    </option>
                </select>
                @error('status')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Tombol Aksi -->
            <div class="flex justify-between">
                <button type="submit"
                    class="px-4 py-2 bg-blue-500 text-white rounded-lg shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400">
                    Update
                </button>
                <a href="{{ route('projects.index') }}"
                    class="px-4 py-2 bg-gray-500 text-white rounded-lg shadow-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-400">
                    Cancel
                </a>
            </div>
        </form>
    </div>
@endsection
