@extends('layouts.main2')

@section('content')
    <div class="container mx-auto py-6 bg-white dark:bg-gray-900 text-gray-800 dark:text-white">
        <h1 class="mb-6 text-4xl font-bold text-center">{{ $title }}</h1>

        <div class="shadow-md rounded-lg p-6 mb-6 dark:bg-gray-800">
            <div>
                <h3 class="text-2xl font-semibold mb-4">{{ $project->name }}</h3>

                <!-- Menampilkan tanggal -->
                <p class="mb-2">
                    <strong class="font-medium">Tanggal:</strong>
                    {{ $project->tanggal ? $project->tanggal->format('d M Y') : 'Tanggal tidak tersedia' }}
                </p>

                <p class="mb-2 dark:text-gray-400">
                    <strong class="font-medium dark:text-white">Deskripsi:</strong><br>
                    {{ $project->description ?? 'Tidak ada deskripsi.' }}
                </p>

                <p>
                    <strong class="font-medium">Status:</strong>
                    <span
                        class="inline-block px-3 py-1 rounded-full text-white
                        {{ $project->status === 'rencana' ? 'bg-blue-500' : ($project->status === 'progres' ? 'bg-yellow-500' : 'bg-green-500') }}">
                        {{ ucfirst($project->status) }}
                    </span>
                </p>
            </div>
        </div>

        <div class="flex gap-4">
            <a href="{{ route('projects.index') }}"
                class="px-4 py-2 bg-gray-500 text-white rounded-md shadow-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-400">
                Kembali ke Daftar
            </a>
            @auth
                <a href="{{ route('projects.edit', $project->id) }}"
                    class="px-4 py-2 bg-blue-500 text-white rounded-md shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400">
                    Edit
                </a>
            @endauth
        </div>
    </div>
@endsection
