@extends('layouts.main2')

@section('content')
    <div class="container mx-auto my-5 p-6 rounded-lg shadow-md dark:shadow-gray-800 bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
        {{-- Header --}}

        <div class="text-center border-b pb-4 mb-4">
            <h1 class="text-2xl font-semibold">{{ $title }}</h1>
            <h2 class="text-xl mt-1">~ {{ $longwis->nama }} ~</h2>
        </div>

        {{-- Detail Informasi --}}
        <div class="grid grid-cols-2 gap-4 mb-6">
            <div>
                @if ($longwis->alamat)
                    <p class=""><span class="font-semibold">Alamat:</span> {{ $longwis->alamat }}</p>
                @endif
                @if ($longwis->penduduk)
                    <p class=""><span class="font-semibold">Total Penduduk:</span> {{ $longwis->penduduk }}
                        Warga</p>
                @endif
                @if ($longwis->keluarga)
                    <p class=""><span class="font-semibold">Total Keluarga:</span> {{ $longwis->keluarga }}
                        Keluarga</p>
                @endif
                @if ($longwis->rumah)
                    <p class=""><span class="font-semibold">Total Rumah:</span> {{ $longwis->rumah }} Rumah
                    </p>
                @endif
            </div>

            <div>
                @if ($longwis->panjang_lorong)
                    <p class=""><span class="font-semibold">Panjang Lorong:</span>
                        {{ $longwis->panjang_lorong }} m</p>
                @endif
                @if ($longwis->lebar_depan)
                    <p class=""><span class="font-semibold">Lebar Depan:</span> {{ $longwis->lebar_depan }}
                        m</p>
                @endif
                @if ($longwis->lebar_tengah)
                    <p class=""><span class="font-semibold">Lebar Tengah:</span>
                        {{ $longwis->lebar_tengah }} m</p>
                @endif
                @if ($longwis->lebar_belakang)
                    <p class=""><span class="font-semibold">Lebar Belakang:</span>
                        {{ $longwis->lebar_belakang }} m</p>
                @endif
                @if ($longwis->koordinat_lorong)
                    <p class=""><span class="font-semibold">Koordinat:</span>
                        {{ $longwis->koordinat_lorong }} m</p>
                @endif
            </div>
        </div>

        {{-- Koordinat --}}
        @if ($longwis->lintang_depan && $longwis->bujur_depan)
            <div class="mb-4">
                <h3 class="font-semibold mb-2">Titik Lorong Depan</h3>
                <p class="">Lintang / Latitude: {{ $longwis->lintang_depan }}</p>
                <p class="">Bujur / Longitude: {{ $longwis->bujur_depan }}</p>
            </div>
        @endif

        @if ($longwis->lintang_belakang && $longwis->bujur_belakang)
            <div class="mb-4">
                <h3 class="font-semibold mb-2">Titik Lorong Belakang</h3>
                <p class="">Lintang / Latitude: {{ $longwis->lintang_belakang }}</p>
                <p class="">Bujur / Longitude: {{ $longwis->bujur_belakang }}</p>
            </div>
        @endif

        {{-- Tombol Aksi --}}
        @auth
            <div class="flex justify-end mt-4">
                <a href="{{ route('longwis.edit', $longwis->id) }}"
                    class="bg-yellow-400 text-white px-4 py-2 rounded hover:bg-yellow-500">
                     Edit
                 </a>
                <form action="{{ route('longwis.destroy', $longwis->id) }}" method="POST"
                    onsubmit="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Delete</button>
                </form>
            </div>
        @endauth
    </div>
@endsection
