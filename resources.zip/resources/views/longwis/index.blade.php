@extends('layouts.main2')

@section('content')
    <div class="container mx-auto py-4 bg-white dark:bg-gray-900 text-gray-800 dark:text-white">
        <h1 class="mb-4 py-4 text-4xl text-center font-semibold">{{ $title }}</h1>
        <div class="flex justify-between items-center gap-2 mb-2">
            @auth
                <div class="text-center my-5">
                    <a href="{{ route('article.create') }}"
                        class="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                        Create
                    </a>
                </div>
            @endauth
            {{-- FITUR SEARCH --}}
            <form method="GET" action="{{ route('longwis.index') }}" class="flex justify-end">
                <div class="flex items-center gap-3 shadow-md p-3 rounded-lg w-full max-w-md">
                    <!-- Input Field -->
                    <input
                        type="text"
                        name="search"
                        value="{{ request('search') }}"
                        class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-700 placeholder-gray-400"
                        placeholder="Cari Data Longwis"
                    />
                    <!-- Submit Button -->
                    <button
                        type="submit"
                        class="flex-shrink-0 px-5 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-1 transition-all duration-150">
                        Cari
                    </button>
                </div>
            </form>

        </div>
        {{-- OVERFLOW (SCROLL BAR) --}}
        <style>
            /* Kustomisasi Scrollbar */
            ::-webkit-scrollbar {
                width: 10px;
                /* Lebar scrollbar vertikal */
                height: 10px;
                /* Tinggi scrollbar horizontal */
            }

            ::-webkit-scrollbar-thumb {
                background-color: #a0aec0;
                /* Warna scrollbar */
                border-radius: 6px;
                /* Membuat sudut bulat */
            }

            ::-webkit-scrollbar-track {
                background-color: #f7fafc;
                /* Warna latar belakang track */
            }
        </style>
        {{-- UTAMA --}}
        <article class="relative overflow-hidden rounded-lg-md shadow-sm transition hover:shadow-lg">
            <div class="mx-auto rounded-lg border border-gray-200 dark:border-gray-600 custom-scrollbar">
                <div class="overflow-x-auto scrollbar-thin rounded-t-lg">
                    <table class="min-w-full divide-y-2 divide-gray-200 dark:divide-gray-600 text-sm">
                        <thead class="ltr:text-left rtl:text-right">
                            <tr>
                                <th class="whitespace-nowrap px-4 py-2 font-medium">Nama</th>
                                <th class="whitespace-nowrap px-4 py-2 font-medium">Tanggal</th>
                                <th class="whitespace-nowrap px-4 py-2 font-medium">Alamat</th>
                                <th class="whitespace-nowrap px-4 py-2 font-medium">Penduduk</th>
                                <th class="whitespace-nowrap px-4 py-2 font-medium">Rumah</th>
                                <th class="whitespace-nowrap px-4 py-2 font-medium">Detail</th>
                            </tr>
                        </thead>
                        @foreach ($longwis as $item)
                            <tbody class="border border-gray-200 dark:border-gray-600">
                                <tr>
                                    <td class="whitespace-nowrap px-4 py-2">{{ $item->nama }}</td>
                                    <td class="whitespace-nowrap px-4 py-2">{{ $item->tanggal }}</td>
                                    <td class="whitespace-nowrap px-4 py-2">{{ $item->alamat }}</td>
                                    <td class="whitespace-nowrap px-4 py-2">{{ $item->penduduk }}</td>
                                    <td class="whitespace-nowrap px-4 py-2">{{ $item->rumah }}</td>
                                    <td class="whitespace-nowrap px-4 py-2">
                                        <a href="{{ route('longwis.show', $item->id) }}"
                                            class="text-blue-500 hover:text-blue-700">Lihat Detail</a>
                                    </td>
                                    <td class="whitespace-nowrap px-4 py-2">
                                        @auth
                                            <form action="{{ route('longwis.destroy', $item->id) }}" method="POST"
                                                class="inline-block">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="text-red-500 hover:text-red-700 ml-2"
                                                    onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Delete</button>
                                            </form>
                                        @endauth
                                    </td>
                                </tr>
                            </tbody>
                        @endforeach
                    </table>
                </div>
                {{-- SEARCH + PAGINATION --}}
                <div class="rounded-b-lg border-t border-gray-200 dark:border-gray-600 px-4 py-2">
                    <ol class="flex justify-end gap-1 text-xs font-medium">
                        {{-- Tombol Previous --}}
                        @if ($longwis->onFirstPage())
                            <li>
                                <span class="inline-flex size-8 items-center justify-center rounded-md cursor-not-allowed">
                                    <span class="sr-only">Prev Page</span>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="size-3" viewBox="0 0 20 20"
                                        fill="currentColor">
                                        <path fill-rule="evenodd"
                                            d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                                            clip-rule="evenodd" />
                                    </svg>
                                </span>
                            </li>
                        @else
                            <li>
                                <a href="{{ $longwis->previousPageUrl() }}"
                                    class="inline-flex size-8 items-center justify-center rounded-md">
                                    <span class="sr-only">Prev Page</span>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="size-3" viewBox="0 0 20 20"
                                        fill="currentColor">
                                        <path fill-rule="evenodd"
                                            d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                                            clip-rule="evenodd" />
                                    </svg>
                                </a>
                            </li>
                        @endif

                        {{-- Nomor Halaman --}}
                        @foreach ($longwis->links()->elements[0] as $page => $url)
                            @if ($page == $longwis->currentPage())
                                <li
                                    class="block size-8 rounded border-blue-600 bg-blue-600 text-center leading-8 text-white">
                                    {{ $page }}
                                </li>
                            @else
                                <li>
                                    <a href="{{ $url }}" class="block size-8 rounded-md text-center leading-8">
                                        {{ $page }}
                                    </a>
                                </li>
                            @endif
                        @endforeach

                        {{-- Tombol Next --}}
                        @if ($longwis->hasMorePages())
                            <li>
                                <a href="{{ $longwis->nextPageUrl() }}"
                                    class="inline-flex size-8 items-center justify-center rounded-md">
                                    <span class="sr-only">Next Page</span>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="size-3" viewBox="0 0 20 20"
                                        fill="currentColor">
                                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10l7.293-6.707z"
                                            clip-rule="evenodd" />
                                    </svg>
                                </a>
                            </li>
                        @else
                            <li>
                                <span class="inline-flex size-8 items-center justify-center rounded-md cursor-not-allowed">
                                    <span class="sr-only">Next Page</span>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="size-3" viewBox="0 0 20 20"
                                        fill="currentColor">
                                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10l7.293-6.707z"
                                            clip-rule="evenodd" />
                                    </svg>
                                </span>
                            </li>
                        @endif
                    </ol>
                </div>
            </div>
        </article>
    </div>
@endsection
