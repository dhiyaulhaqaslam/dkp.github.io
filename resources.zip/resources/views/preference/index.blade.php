<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __($title) }}
        </h2>
    </x-slot>

    <div class="shadow-md rounded-md p-6 bg-white dark:bg-gray-800 text-gray-800 dark:text-white">
        <div class="flex items-center justify-center space-x-6">
            <!-- Tema Terang -->
            <div id="light-status"
                class="items-center text-lg font-medium text-gray-700 dark:text-gray-300 relative p-3 rounded-lg border border-gray-300 hidden">
                <span class="text-yellow-400 text-2xl">🌞</span>
                <span class="ml-2 text-blue-500 font-bold">Tema Terang</span>
            </div>

            <!-- Tema Gelap -->
            <div id="dark-status"
                class="items-center text-lg font-medium text-gray-700 dark:text-gray-300 relative p-3 rounded-lg border border-gray-300 hidden">
                <span class="text-gray-600 text-2xl">🌙</span>
                <span class="ml-2 text-blue-500 font-bold">Tema Gelap</span>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const lightStatus = document.getElementById('light-status');
            const darkStatus = document.getElementById('dark-status');

            // Function to update theme status
            const updateThemeStatus = () => {
                const isDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;

                if (isDarkMode) {
                    lightStatus.classList.add('hidden');
                    lightStatus.classList.remove('flex');
                    darkStatus.classList.remove('hidden');
                    darkStatus.classList.add('flex');
                } else {
                    darkStatus.classList.add('hidden');
                    darkStatus.classList.remove('flex');
                    lightStatus.classList.remove('hidden');
                    lightStatus.classList.add('flex');
                }
            };

            // Initial theme check
            updateThemeStatus();

            // Listen for changes in system theme
            window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', updateThemeStatus);
        });
    </script>

</x-app-layout>
