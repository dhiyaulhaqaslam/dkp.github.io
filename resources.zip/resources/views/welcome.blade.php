<x-home-layout>
    <div class="bg-cover" style="background-image: url('{{ asset('ASSETS/banner1-pangan.jpg') }}')">
        <section class="bg-blend-color-dodge bg-gray-700/70 dark:bg-gray-900/75 text-white stroke-slate-950">
            <div class="mx-auto max-w-screen-xl px-4 py-32 lg:flex lg:h-screen lg:items-center">
                <div class="mx-auto max-w-3xl text-center">
                    <h1 class="bg-clip-text text-3xl font-extrabold sm:text-5xl">
                        Bidang Konsumsi dan

                        <span class="mt-2 pb-2 sm:block "> Penganekaragaman Pangan </span>
                    </h1>

                    <p class="mx-auto mt-4 max-w-xl sm:text-xl/relaxed">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nesciunt illo tenetur fuga ducimus
                        numquam ea!
                    </p>

                    <div class="mt-8 flex flex-wrap justify-center gap-4">
                        <a class="block w-full rounded border-indigo-500 bg-indigo-500 px-12 py-3 ring-indigo-500 text-sm text-white font-medium hover:bg-transparent hover:text-white focus:outline-none focus:ring active:text-opacity-75 sm:w-auto" href="{{ route('register') }}">
                            Get Started
                        </a>

                        <a class="block w-full rounded border-indigo-500 px-12 py-3 text-sm font-medium  ring-indigo-500 hover:bg-indigo-500 focus:outline-none hover:text-white focus:ring sm:w-auto"
                            href="{{ route('about.index') }}">
                            Learn More
                        </a>
                    </div>
                </div>
            </div>
        </section>
        {{-- PRIORITY --}}
        <section class="py-8 md:py-16 bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-white">
            <div class="rounded-xl max-w-7xl mx-auto p-10">
                <div class="mx-auto max-w-3xl text-center">
                    <h2 class="text-3xl font-bold sm:text-4xl">Priority</h2>

                    <p class="mt-4 sm:text-xl dark:text-gray-400">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione dolores laborum labore
                        provident impedit esse recusandae facere libero harum sequi.
                    </p>
                </div>
                <dl class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-8">
                    <div
                        class="flex flex-col items-center rounded-lg border border-black dark:border-gray-600 p-6 shadow-md text-center dark:bg-gray-800">
                        <dt class="text-xl font-medium">Diversifikasi dan Ketahanan Pangan</dt>

                    </div>
                    <div
                        class="flex flex-col items-center rounded-lg border border-black dark:border-gray-600 p-6 shadow-md text-center dark:bg-gray-800">
                        <dt class="text-xl font-medium">Pengawasan Keamanan Pangan
                        </dt>
                    </div>
                    <div
                        class="flex flex-col items-center rounded-lg border border-black dark:border-gray-600 p-6 shadow-md text-center dark:bg-gray-800">
                        <dt class="text-xl font-medium">Penanganan Kerawanan Pangan</dt>
                    </div>
                </dl>
            </div>
        </section>
        {{-- BERITA ARTIKEL --}}
        <section class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-white py-8">
            <div class="">
                <h2 class="text-center text-3xl sm:text-4xl font-bold py-4 mb-2">Berita Terkini</h2>
            </div>
            <div
                class="justify-items-center sm:w-4/5 md:w-3/4 lg:w-3/5 xl:w-3/5 2xl:w-1/2 custom-3xl:w-2/5 custom-4xl:w-1/3 custom-5xl:w-1/4 container mx-auto">
                <div class="w-fit grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-2 justify-items-center">
                    @foreach ($articles as $article)
                        <article
                            class="relative overflow-hidden rounded-lg border border-gray-100 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-md 2xl:max-w-xl transition hover:shadow-lg dark:shadow-gray-800 dark:hover:shadow-gray-800">
                            <span
                                class="absolute -right-px -top-px rounded-bl-3xl rounded-tr-3xl bg-indigo-500 py-2 px-2 font-semibold uppercase text-white">
                                {{ $article->tanggal }}
                            </span>
                            <a href="{{ route('article.show', $article->id) }}" class="w-full object-cover"><img class=""
                                    alt="" src="{{ asset('storage/' . $article->image) }}"></a>
                            <div class="p-4 sm:p-6">
                                <a href="{{ route('article.show', $article->id) }}">
                                    <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                                        {{ $article->title }}</h3>
                                </a>
                                <p class="mt-2 line-clamp-3 text-sm/relaxed text-gray-400">
                                    {{ Str::limit($article->content, 100) }}
                                </p>
                                <a href="{{ route('article.show', $article->id) }}"
                                    class="group mt-4 inline-flex items-center gap-1 text-sm font-medium text-indigo-500">
                                    Find out more
                                    <span aria-hidden="true"
                                        class="block transition-all group-hover:ms-0.5 rtl:rotate-180">&rarr;</span>
                                </a>
                            </div>
                        </article>
                    @endforeach
                </div>
        </section>
        <!-- SPONSOR -->
        <div class="py-16 sm:py-20 bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-white">
            <div class="mx-auto max-w-7xl px-6 lg:px-8">
                <div
                    class="mx-auto mt-10 grid max-w-lg grid-cols-4 items-center gap-x-8 gap-y-10 sm:max-w-xl sm:grid-cols-6 sm:gap-x-10 lg:mx-0 lg:max-w-none lg:grid-cols-5">
                    <img class="col-span-2 max-h-12 w-full object-contain lg:col-span-1"
                        src="{{ asset('ASSETS/logolongwis.png') }}" alt="Transistor" width="158" height="48">
                    <img class="col-span-2 max-h-12 w-full object-contain lg:col-span-1"
                        src="{{ asset('ASSETS/LogoBulogpng.png') }}" alt="Reform" width="158" height="48">
                    <img class="col-span-2 max-h-12 w-full object-contain lg:col-span-1"
                        src="{{ asset('ASSETS/BPOM.png') }}" alt="Tuple" width="158" height="48">
                    <img class="col-span-2 max-h-12 w-full objxect-contain sm:col-start-2 lg:col-span-1"
                        src="{{ asset('ASSETS/Badan Pangan Nasional.png') }}" alt="SavvyCal" width="158"
                        height="48">
                    <img class="col-span-2 col-start-2 max-h-12 w-full object-contain sm:col-start-auto lg:col-span-1"
                        src="{{ asset('ASSETS/DISDAG.png') }}" alt="Statamic" width="158" height="48">
                </div>
            </div>
        </div>
    </div>
</x-home-layout>
