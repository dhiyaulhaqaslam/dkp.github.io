@extends('layouts.main2')

@section('content')
    <div class="p-6 bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-white">
        <h2 class="text-2xl font-bold text-center text-gray-800 mb-6">
            Kritik dan Saran
        </h2>

        @if (session('success'))
            <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
                {{ session('success') }}
            </div>
        @endif

        <!-- Form Kritik dan Saran -->
        <form  action="{{ route('contact.store') }}" method="POST"
            class="max-w-3xl mx-auto p-6 rounded-lg shadow-md bg-gray-100 dark:bg-gray-800">
            @csrf
            <div class="mb-4">
                <label for="name" class="block text-sm font-medium">Nama</label>
                <input type="text" id="name" name="name" placeholder="Masukkan Nama Anda"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-gray-800"
                    required>
            </div>

            <div class="mb-4">
                <label for="email" class="block text-sm font-medium">Email</label>
                <input type="email" id="email" name="email" placeholder="Masukkan Email Anda"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-gray-800"
                    required>
            </div>

            <div class="mb-4">
                <label for="message" class="block text-sm font-medium">Pesan</label>
                <textarea id="message" name="message" rows="4" placeholder="Masukkan Kritik dan Saran Anda"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-gray-800"
                    required></textarea>
            </div>

            <button type="submit"
                class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition duration-300">
                Kirim Kritik dan Saran
            </button>
        </form>
    </div>
    <center>
        <button id="toggle1" class="px-3 py-2 text-base rounded-md focus:outline-none">
            Tampilkan Kritik Saran
            <svg class="w-4 h-4 inline-block ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7">
                </path>
            </svg>
        </button>
    </center>
    <form id="dropdown" class="max-w-3xl hidden mx-auto mb-12 mt-6 text-gray-800 dark:text-white bg-gray-100 dark:bg-gray-800 rounded-md">
        <div class="">
            <div class="p-6">
                <h2 class="text-2xl font-bold text-center mb-6">Daftar Kritik dan Saran</h2>

                @forelse ($feedbacks as $feedback)
                    <div class="mb-4 p-4 rounded-lg hover:shadow-md hover:shadow-gray-900 bg-gray-100 border dark:border-gray-700 text-gray-100 dark:text-gray-400">
                        <h3 class="text-lg font-bold">{{ $feedback->name }}</h3>
                        <p class="text-sm">{{ $feedback->email }}</p>
                        <p class="mt-2">{{ $feedback->message }}</p>
                    </div>
                @empty
                    <p class= text-center">Belum ada kritik dan saran.</p>
                @endforelse

                {{ $feedbacks->links() }}
            </div>
        </div>
    </form>
    <script>
        const toggleButton = document.getElementById('toggle1');
        const dropdownMenu = document.getElementById('dropdown');

        toggleButton.addEventListener('click', () => {
            dropdownMenu.classList.toggle('hidden');
        });
    </script>
@endsection
