@extends('layouts.main2')

@section('content')
    <div class="pt-10 bg-gray-100 font-poppins">
        <div class="container mx-auto">
            <section
                class="overflow-hidden bg-[url(https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?q=80&w=2670&auto=format&fit=crop)] bg-cover bg-top bg-no-repeat">
                <div class="bg-black/50 p-8 md:p-12 lg:px-16 lg:py-24 text-center">
                    <div class="text-center ltr:sm:text-left rtl:sm:text-right">
                        <h2 class="text-2xl font-bold text-white sm:text-3xl md:text-5xl">Tentang kami</h2>

                        <p class="hidden max-w-2xl mx-auto text-white/90 md:mt-6 md:block md:text-lg md:leading-relaxed">
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Inventore officia corporis quasi
                            doloribus iure architecto quae voluptatum beatae excepturi dolores.
                        </p>

                        <div class="mt-4 sm:mt-8">
                            <a href="{{ route('article.index') }}"
                                class="inline-block rounded-full bg-indigo-600 px-12 py-3 text-sm font-medium text-white transition hover:bg-indigo-700 focus:outline-none focus:ring focus:ring-yellow-400">
                                More
                            </a>
                        </div>
                    </div>
                </div>
            </section>
            <style>
                .keen-slider {
                    display: flex;
                    overflow: hidden;
                    /* Sesuaikan jarak antar kotak */
                }

                .keen-slider__slide {
                    flex: 0 0 auto;
                    /* Agar item tidak mengecil */
                    scroll-snap-align: start;
                    width: calc(100% / 3);
                    /* Sesuaikan jumlah item per tampilan */
                }

                @media (min-width: 1024px) {
                    .keen-slider__slide {
                        width: calc(100% / 3);
                        /* Ganti dengan jumlah slide yang sesuai */
                    }
                }
            </style>

            <script type="module">
                import KeenSlider from 'https://cdn.jsdelivr.net/npm/keen-slider@6.8.6/+esm'

                const keenSlider = new KeenSlider(
                    '#keen-slider', {
                        loop: true,
                        slides: {
                            origin: 'center',
                            perView: 1.25,
                            spacing: 16,
                        },
                        breakpoints: {
                            '(min-width: 1024px)': {
                                slides: {
                                    origin: 'auto',
                                    perView: 1.5,
                                    spacing: 32,
                                },
                            },
                        },
                    },
                    []
                )

                const keenSliderPrevious = document.getElementById('keen-slider-previous')
                const keenSliderNext = document.getElementById('keen-slider-next')

                const keenSliderPreviousDesktop = document.getElementById('keen-slider-previous-desktop')
                const keenSliderNextDesktop = document.getElementById('keen-slider-next-desktop')

                keenSliderPrevious.addEventListener('click', () => keenSlider.prev())
                keenSliderNext.addEventListener('click', () => keenSlider.next())

                keenSliderPreviousDesktop.addEventListener('click', () => keenSlider.prev())
                keenSliderNextDesktop.addEventListener('click', () => keenSlider.next())
            </script>

            <section class="w-full bg-white dark:bg-gray-900 text-gray-800 dark:text-white">
                <div class="mx-auto max-w-[1530px] py-12 px-6 lg:py-16 lg:pe-0 lg:ps-0 xl:py-24">
                    <div class="grid grid-cols-1 gap-8 lg:grid-cols-3 lg:items-center lg:gap-16">
                        <div class="max-w-xl text-center ltr:sm:text-left rtl:sm:text-right">
                            <h2 class="text-3xl font-bold tracking-tight sm:text-4xl text-start">
                                Profil Dinas Ketahanan Pangan Kota Makassar
                            </h2>

                            <p class="mt-4 text-start">
                                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptas veritatis illo
                                placeat
                                harum porro optio fugit a culpa sunt id!
                            </p>

                            <div class="hidden lg:mt-8 lg:flex lg:gap-4 justify-start">
                                <button aria-label="Previous slide" id="keen-slider-previous-desktop"
                                    class="rounded-full border border-indigo-600 p-3 text-indigo-600 transition hover:bg-indigo-600 hover:text-white">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor" class="size-5 rtl:rotate-180">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M15.75 19.5L8.25 12l7.5-7.5" />
                                    </svg>
                                </button>

                                <button aria-label="Next slide" id="keen-slider-next-desktop"
                                    class="rounded-full border border-indigo-600 p-3 text-indigo-600 transition hover:bg-indigo-600 hover:text-white">
                                    <svg class="size-5 rtl:rotate-180" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9 5l7 7-7 7" stroke-linecap="round" stroke-linejoin="round"
                                            stroke-width="2" />
                                    </svg>
                                </button>
                            </div>
                        </div>


                        <div class="-mx-6 lg:col-span-2 lg:mx-0">
                            <div id="keen-slider" class="keen-slider">
                                @foreach ($informasi->take(3) as $info)
                                    <div class="keen-slider__slide">
                                        <blockquote
                                            class="flex h-full flex-col justify-between p-6 shadow-sm sm:p-8 lg:p-12 bg-gray-200/25 dark:bg-gray-800 text-gray-800 dark:text-white">
                                            <div>
                                                <div class="flex gap-0.5 text-green-500">
                                                    <svg class="size-5" fill="currentColor" viewBox="0 0 20 20"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                                    </svg>

                                                    <svg class="size-5" fill="currentColor" viewBox="0 0 20 20"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                                    </svg>

                                                    <svg class="size-5" fill="currentColor" viewBox="0 0 20 20"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                                    </svg>

                                                    <svg class="size-5" fill="currentColor" viewBox="0 0 20 20"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                                    </svg>

                                                    <svg class="size-5" fill="currentColor" viewBox="0 0 20 20"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                                    </svg>
                                                </div>

                                                <div class="mt-4">
                                                    <p class="text-2xl font-bold text-indigo-600 sm:text-3xl">
                                                        {{ $info->judul }}
                                                    </p>

                                                    <p class="mt-4 leading-relaxed">
                                                        {{ Str::limit($info->deskripsi, 180) }}
                                                    </p>
                                                </div>
                                            </div>
                                        </blockquote>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>

                    <div class="mt-8 flex justify-center gap-4 lg:hidden">
                        <button aria-label="Previous slide" id="keen-slider-previous"
                            class="rounded-full border border-indigo-600 p-4 text-indigo-600 transition hover:bg-indigo-600 hover:text-white">
                            <svg class="size-5 -rotate-180 transform" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9 5l7 7-7 7" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
                            </svg>
                        </button>

                        <button aria-label="Next slide" id="keen-slider-next"
                            class="rounded-full border border-indigo-600 p-4 text-indigo-600 transition hover:bg-indigo-600 hover:text-white">
                            <svg class="size-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M9 5l7 7-7 7" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
                            </svg>
                        </button>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <div class="space-y-4 container py-8 mx-auto">
        <section class="my-8">
            <div class="mx-auto max-w-screen-xl px-4 py-8 sm:px-6 lg:px-8">
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2 md:items-center md:gap-8">
                    <div>
                        <div class="max-w-lg md:max-w-none text-black dark:text-white bg-gray-100 dark:bg-gray-800 py-10 px-6 rounded-md">
                            <h2 class="text-2xl font-semibold sm:text-3xl">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            </h2>

                            <p class="mt-4 text-gray-500 dark:text-gray-400">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur doloremque saepe
                                architecto maiores repudiandae amet perferendis repellendus, reprehenderit voluptas
                                sequi.
                            </p>
                        </div>
                    </div>

                    <div>
                        <div>
                            <td class="border px-4 py-2">
                                @php
                                    // Mengambil informasi pertama (indeks 0)
                                    $info = $informasi[0] ?? null; // Default null jika tidak ada informasi pertama
                                @endphp

                                @if ($info && $info->video_link)
                                    @php
                                        // Menggunakan video_link dari database
                                        $videoLink = $info->video_link;

                                        // Regex untuk mengambil ID video
                                        preg_match(
                                            '/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?\/?|watch\?v=))|youtu\.be\/)([^\&\?\/]+)/',
                                            $videoLink,
                                            $matches,
                                        );
                                        $videoId = $matches[1] ?? null;
                                    @endphp

                                    @if ($videoId)
                                        <!-- Tampilkan thumbnail video pertama -->
                                        <a href="{{ $videoLink }}" class="flex justify-center" target="_blank">
                                            <img src="https://img.youtube.com/vi/{{ $videoId }}/hqdefault.jpg"
                                                class="rounded" alt="Thumbnail Video">
                                        </a>
                                    @else
                                        <!-- Tampilkan gambar default jika ID video tidak ditemukan -->
                                        <img src="https://images.unsplash.com/photo-1731690415686-e68f78e2b5bd?q=80&w=2670&auto=format&fit=crop"
                                            class="rounded" alt="Thumbnail Default">
                                    @endif
                                @else
                                    <!-- Jika video_link kosong -->
                                    <img src="https://images.unsplash.com/photo-1731690415686-e68f78e2b5bd?q=80&w=2670&auto=format&fit=crop"
                                        class="rounded" alt="Thumbnail Default">
                                @endif
                            </td>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="my-8">
            <div class="mx-auto max-w-screen-xl px-4 py-8 sm:px-6 lg:px-8">
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2 md:items-center md:gap-8">
                    <div>
                        @php
                            // Mengambil informasi ke-2 (indeks 1)
                            $info = $informasi[1] ?? null; // Default null jika tidak ada informasi ke-2
                        @endphp

                        @if ($info && $info->video_link)
                            @php
                                // Ekstrak ID video menggunakan regex
                                preg_match(
                                    '/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?\/?|watch\?v=))|youtu\.be\/)([^\&\?\/]+)/',
                                    $info->video_link,
                                    $matches,
                                );
                                $videoId = $matches[1] ?? null;
                            @endphp

                            @if ($videoId)
                                <!-- Tampilkan thumbnail video -->
                                <a href="{{ $info->video_link }}" class="flex justify-center" target="_blank">
                                    <img src="https://img.youtube.com/vi/{{ $videoId }}/hqdefault.jpg"
                                        class="rounded object-cover" alt="Thumbnail Video">
                                </a>
                            @else
                                <!-- Tampilkan gambar default jika ID video tidak ditemukan -->
                                <img src="https://images.unsplash.com/photo-1731690415686-e68f78e2b5bd?q=80&w=2670&auto=format&fit=crop"
                                    class="rounded" alt="Gambar Default">
                            @endif
                        @else
                            <!-- Jika tidak ada video link, tampilkan gambar default -->
                            <img src="https://images.unsplash.com/photo-1731690415686-e68f78e2b5bd?q=80&w=2670&auto=format&fit=crop"
                                class="rounded" alt="Gambar Default">
                        @endif
                    </div>
                    <div>
                        <div class="max-w-lg md:max-w-none text-black dark:text-white bg-gray-100 dark:bg-gray-800 py-10 px-6 rounded-md">
                            <h2 class="text-2xl font-semibold sm:text-3xl">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            </h2>

                            <p class="mt-4 text-gray-500 dark:text-gray-400">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur doloremque saepe
                                architecto maiores repudiandae amet perferendis repellendus, reprehenderit voluptas
                                sequi.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
